package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import dao.TipoElectroDao;
import modelo.TipoElectro;

public class TipoElectroService implements TipoElectroDao{ 
	
	@Override
	public List<TipoElectro> listar()
	{
		List<TipoElectro> lista = new ArrayList<TipoElectro>();
		String query = "select id, descripcion from tipelectro order by descripcion";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt("id");
				String descripcion = rs.getString("descripcion");
				TipoElectro t = new TipoElectro(id, descripcion);
				lista.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}
	
	@Override
	public TipoElectro buscar (int id)
	{
		String query = "select descripcion from tipelectro where id = ? order by descripcion";
		TipoElectro tipelectro = null;
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			smt.setInt(1, id);
			ResultSet rs = smt.executeQuery();
			while (rs.next())
			{
				String descripcion = rs.getString("descripcion");
				tipelectro = new TipoElectro(id, descripcion);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tipelectro;
	}

}
