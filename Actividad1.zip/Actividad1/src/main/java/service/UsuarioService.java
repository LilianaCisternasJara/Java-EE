package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;
import dao.UsuarioDao;
import modelo.Usuario;

public class UsuarioService implements UsuarioDao{
	
	@Override
	public Usuario buscar(String user, String pass)
	{
		Usuario usuario = null;
		String query = "select id, user, pass, rol from usuario where user = ? and pass = ?";
		PreparedStatement smt;
		try {
			smt = Conexion.getInstancia().prepareStatement(query);
			smt.setString(1, user);
			smt.setString(2, pass);
			ResultSet rs = smt.executeQuery();
			while (rs.next()) {
				
				int id = rs.getInt("id");
				int rol = rs.getInt("rol");
				usuario = new Usuario(id, user, pass, rol);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return usuario;
		
		}
		
	}

