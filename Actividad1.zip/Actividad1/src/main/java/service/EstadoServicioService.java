package service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import dao.EstadoServicioDao;
import modelo.EstadoServicio;

public class EstadoServicioService implements EstadoServicioDao{
	
	@Override
	public List<EstadoServicio> listar()
	{
		List<EstadoServicio> lista = new ArrayList<EstadoServicio>();
		String query = "select id, descripcion from eservicio order by descripcion";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				int id = rs.getInt("id");
				String descripcion = rs.getString("descripcion");
				EstadoServicio e = new EstadoServicio(id, descripcion);
				lista.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}
	
	@Override
	public EstadoServicio buscar(int id)
	{
		EstadoServicio estado = null;
		String query = "select descripcion from eservicio where id = ?";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			smt.setInt(1, id);
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				String descripcion = rs.getString("descripcion");
				estado = new EstadoServicio(id, descripcion);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return estado;
	}

}
