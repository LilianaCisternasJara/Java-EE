package service;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import dao.ClienteDao;
import modelo.Cliente;
import modelo.EstadoServicio;
import modelo.TipoElectro;



public class ClienteService implements ClienteDao{

	@Override
	public int agregar(Cliente cliente) 
	{
		String query = "insert into cliente(id, nombres, apellidos, telefono, direccion,tipelectro, eservicio, fsolicitud, fultactualizacion) values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			smt.setString(1,cliente.getId());
			smt.setString(2, cliente.getNombres());
			smt.setString(3, cliente.getApellidos());
			smt.setString(4, cliente.getTelefono());//(setInt)
			smt.setString(5, cliente.getDireccion());
			smt.setInt(6, cliente.getTipelectro().getId());
			smt.setInt(7, cliente.getEservicio().getId());
			smt.setString(8, cliente.getFsolicitud());
			smt.setString(9, cliente.getFultactualizacion());
			
			int r = smt.executeUpdate();
			return r;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	@Override
	public int eliminar(String id)
	{
		String query = "delete from cliente where id = ?";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			smt.setString(1, id);
			int r = smt.executeUpdate();
			return r;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
	@Override
	public int modificar(Cliente cliente)
	{
		String query = "update cliente set nombres = ?, apellidos = ?, telefono = ?, direccion = ?, tipelectro = ?, eservicio = ?, fsolicitud = ?, fultactualizacion = ? where id ";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			
			smt.setString(1, cliente.getNombres());
			smt.setString(2, cliente.getApellidos());
			smt.setString(3, cliente.getTelefono());//setInt
			smt.setString(4, cliente.getDireccion());
			smt.setInt(5, cliente.getTipelectro().getId());
			smt.setInt(6, cliente.getTipelectro().getId());
			smt.setInt(7, cliente.getEservicio().getId());
			smt.setString(8, cliente.getFsolicitud());
			smt.setString(9, cliente.getFultactualizacion());
			smt.setString(10, cliente.getId());
			
			int r = smt.executeUpdate();
			return r;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public List<Cliente> listar()
	{
		List<Cliente> lista = new ArrayList();
		String query = "select id, nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, fultactualizacion from cliente order by id";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			ResultSet rs = smt.executeQuery();
			while (rs.next()) {
				String id = rs.getString("id");
				String nombres = rs.getString("nombres");
				String apellidos = rs.getString("apellidos");
				String telefono = rs.getString("telefono");//int
				String direccion = rs.getString("direccion");
				int tipelectroId = rs.getInt("tipelectro");
				int eservicioId = rs.getInt("eservicio");
				String fsolicitud = rs.getString("fsolicitud");
				String fultactualizacion = rs.getString("fultactualizacion");
				
				TipoElectroService registroTipoElectro = new TipoElectroService();
				TipoElectro tipelectro = registroTipoElectro.buscar(tipelectroId);
				
				EstadoServicioService registroEstadoServicio = new EstadoServicioService();
				EstadoServicio eservicio = registroEstadoServicio.buscar(eservicioId);
				
				Cliente f = new Cliente(id,nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, fultactualizacion);
				lista.add(f);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}
	
	@Override
	public Cliente buscar(String id)
	{
		Cliente cliente = null;
		String query = "select id, nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, futlactualizacion from cliente where id = ? ";
		try {
			PreparedStatement smt = Conexion.getInstancia().prepareStatement(query);
			smt.setString(1, id);
			ResultSet rs = smt.executeQuery();
			while(rs.next())
			{
				String nombres = rs.getString("nombres");
				String apellidos = rs.getString("apellidos");
				String telefono= rs.getString("telefono");//(int)
				String direccion = rs.getString("direccion");
				int tipelectroId = rs.getInt("tipelectro");
				int eservicioId = rs.getInt("eservicio");
				String fsolicitud = rs.getString("fsolicitud");
				String fultactualizacion = rs.getString("fultactualizacion");
				
				TipoElectroService registroTipoElectro = new TipoElectroService();
				TipoElectro tipelectro = registroTipoElectro.buscar(tipelectroId);
				
				EstadoServicioService registroEstadoServicio = new EstadoServicioService();
				EstadoServicio eservicio = registroEstadoServicio.buscar(eservicioId);
				
				cliente = new Cliente(id, nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, fultactualizacion);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cliente;
	}
	
	
	
}

//	private List <Formulario> lista;
//
//	public RegistroElectrodomestico(List<Formulario> lista) {
//		this.lista = lista;
//	}
//	
//	public RegistroElectrodomestico() {
//		
//		lista = new ArrayList();
//	}
//
//	public List<Formulario> getLista() {
//		return lista;
//	}
//
//	public void setLista(List<Formulario> lista) {
//		this.lista = lista;
//	}
//	
//	//public boolean agregar(Formulario formulario)
//	{
//		if(buscar(formulario.getId()) == null)
//		{
//			return getLista().add(formulario);
//		}
//		else {
//			return false;
//		}
//	}
//	
//	public Formulario buscar(String id) {
//		for (Formulario f : getLista())
//		{
//			if (f.getId() == (id)) {
//				return f ;
//		}
//	}
//		
//	return null;
//		
//	}
//	public boolean eliminar (String id) {
//		
//		return getLista().remove(buscar(id));
//		
//	}
//	public void modificar(Formulario formulario)
//	{
//		int pos = getLista().indexOf(buscar(formulario.getId()));
//		getLista().set(pos, formulario);
//	}	
//}

