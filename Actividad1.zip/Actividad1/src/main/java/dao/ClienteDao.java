package dao;

import java.util.List;

import modelo.Cliente;

public interface ClienteDao {
	
	int agregar(Cliente cliente);
	
	int eliminar(String id);
	
	int modificar(Cliente cliente);
	
	List<Cliente> listar();
	
	Cliente buscar(String id);

}
