package dao;

import java.util.List;

import modelo.TipoElectro;

public interface TipoElectroDao {
	
	List<TipoElectro> listar();
	
	TipoElectro buscar(int id);

}
