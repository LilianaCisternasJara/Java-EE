package dao;

import modelo.Usuario;

public interface UsuarioDao {
	
	Usuario buscar (String user, String pass);

}
