package dao;

import java.util.List;

import modelo.EstadoServicio;

public interface EstadoServicioDao {
	
	List<EstadoServicio> listar();
	
	EstadoServicio buscar (int id);

}
