package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Usuario;
import service.ClienteService;
import service.EstadoServicioService;
import service.TipoElectroService;
import service.UsuarioService;

/**
 * Servlet implementation class DetalleIndexServlet
 */
@WebServlet("/DetalleIndexServlet")
public class DetalleIndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DetalleIndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		TipoElectroService registroTipoElectro = new TipoElectroService();
		request.getSession().setAttribute("tipelectros", registroTipoElectro.listar());
		EstadoServicioService registroEstadoServicio = new EstadoServicioService();
		request.getSession().setAttribute("eservicio", registroEstadoServicio.listar());
		response.sendRedirect("/Actividad1/indexAct1.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String user = request.getParameter("user");
		String pass = request.getParameter("pass");
		UsuarioService registroUsuario = new UsuarioService();
		
		Usuario usuario = registroUsuario.buscar(user, pass);
		
		if(usuario != null)
		{
			if(usuario.getRol()==1)
			{
				TipoElectroService registroTipoElectro = new TipoElectroService();
				request.getSession().setAttribute("tipelectros", registroTipoElectro.listar());
				EstadoServicioService registroEstadoServicio = new EstadoServicioService();
				request.getSession().setAttribute("eservicio", registroEstadoServicio.listar());
				response.sendRedirect("/Actividad1/indexAct1.jsp");	
			}
			else
			{
				ClienteService registroCliente = new ClienteService();
				request.getSession().setAttribute("key", registroCliente.listar());
				request.getSession().setAttribute("cliente", "cliente");
				response.sendRedirect("/Actividad1/resumen.jsp");	
			}
			
		}
		else
		{
			response.sendRedirect("/Actividad1/home.jsp");
		}
		
	}

}
