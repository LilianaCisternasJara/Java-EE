package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Cliente;
import modelo.EstadoServicio;
import modelo.TipoElectro;
import service.ClienteService;

/**
 * Servlet implementation class ActualizarServlet
 */
@WebServlet("/ActualizarServlet")
public class ActualizarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("id");
		String nombres = request.getParameter("nombres");
		String apellidos = request.getParameter("apellidos");
		String telefono = request.getParameter("telefono");
//		String telefonoString = request.getParameter("fono");
//		int telefono = Integer.parseInt(telefonoString);
		String direccion = request.getParameter("direccion");
		int tipelectroId = Integer.parseInt(request.getParameter("tipelectro"));
		int eservicioId = Integer.parseInt(request.getParameter("eservicio"));
		String fsolicitud = request.getParameter("fsolicitud");
		String fultactualizacion = request.getParameter("fultactualizacion");
		
		TipoElectro tipelectro = new TipoElectro(tipelectroId);
		EstadoServicio eservicio = new EstadoServicio(eservicioId);
		
		Cliente f = new Cliente(id, nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, fultactualizacion);
		
		ClienteService registro = new ClienteService();
		
		int r = registro.modificar(f);
		
		if(r==1) 
		{
			request.getSession().setAttribute("key", registro.listar());
			response.sendRedirect("/Actividad1/resumen.jsp");
		}
		else 
		{
			request.getSession().setAttribute("error", "id ya registrado");
			response.sendRedirect("/Actividad1/modificar.jsp");
		}
		
//		String id = request.getParameter("id");
//		String nombres = request.getParameter("nombres");
//		String apellidos = request.getParameter("apellidos");
//		String telefonoString = request.getParameter("fono");
//		int telefono = Integer.parseInt(telefonoString);
//		String direccion = request.getParameter("direccion");
//		String tipelectro = request.getParameter("tipelectro");
//		String eservicio = request.getParameter("eservicio");
//		String fsolicitud = request.getParameter("fsolicitud");
//		String fultactualizacion = request.getParameter("fultactualizacion");
//		
//		Cliente f = new Cliente(id, nombres, apellidos, telefono, direccion, tipelectro, eservicio, fsolicitud, fultactualizacion);
//		
//		RegistroCliente registro = new RegistroCliente();
//		
//		List<Cliente> lista = (List<Cliente>) request.getSession().getAttribute("key");
//		
//		if(lista != null) {
//			registro.setLista(lista);
//		}
//		registro.modificar(f);
//		request.getSession().setAttribute("key", registro.getLista());
//		
//		response.sendRedirect("/Actividad1/resumen.jsp");
//	}
//
}
}