package modelo;

public class Cliente {
	private String id;
	private String nombres;
	private String apellidos;
	private String telefono;//(int)
	private String direccion;
	private TipoElectro tipelectro;
	private EstadoServicio eservicio;
	private String fsolicitud;
	private String fultactualizacion;
	
	public Cliente(String id, String nombres, String apellidos, String telefono, String direccion, TipoElectro tipelectro,
			EstadoServicio eservicio, String fsolicitud, String fultactualizacion) {
		this.id = id;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.telefono = telefono;
		this.direccion = direccion;
		this.tipelectro = tipelectro;
		this.eservicio = eservicio;
		this.fsolicitud = fsolicitud;
		this.fultactualizacion = fultactualizacion;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public TipoElectro getTipelectro() {
		return tipelectro;
	}

	public void setTipelectro(TipoElectro tipelectro) {
		this.tipelectro = tipelectro;
	}

	public EstadoServicio getEservicio() {
		return eservicio;
	}

	public void setEservicio(EstadoServicio eservicio) {
		this.eservicio = eservicio;
	}

	public String getFsolicitud() {
		return fsolicitud;
	}

	public void setFsolicitud(String fsolicitud) {
		this.fsolicitud = fsolicitud;
	}

	public String getFultactualizacion() {
		return fultactualizacion;
	}

	public void setFultactualizacion(String fultactualizacion) {
		this.fultactualizacion = fultactualizacion;
	}
}
