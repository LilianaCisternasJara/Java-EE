package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	
	private Conexion() {}
	
	
	private static Connection instancia;
	
	public synchronized static Connection getInstancia()
	{
		if(instancia == null) 
		{
			
			String user = "L6Vewg5c4P";//lili
			String pass = "osWE46ZWTR";//12345 0 aiep.2022
			String driver = "com.mysql.cj.jdbc.Driver";
			String url = "jdbc:mysql://remotemysql.com:3306/L6Vewg5c4P?useSSL=false";//192.168.105.37 Electrodomesticos
		
			try {
				Class.forName(driver);
				instancia = DriverManager.getConnection(url, user, pass);
				System.out.println("Conectado");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instancia;
		
	}

}
