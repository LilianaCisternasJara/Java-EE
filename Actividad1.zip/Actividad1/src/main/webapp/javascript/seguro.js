/**
 * 
 */
function eliminar(id) {
    if (confirm("¿Está seguro de eliminar el electrodoméstico?")) {
        document.getElementById("eliminar" + id).submit()
    }
}